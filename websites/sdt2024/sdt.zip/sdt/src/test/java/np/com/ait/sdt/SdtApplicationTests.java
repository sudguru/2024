package np.com.ait.sdt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SdtApplicationTests {

	@Test
	void contextLoads() {
	}

}
